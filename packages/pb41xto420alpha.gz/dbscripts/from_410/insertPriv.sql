INSERT INTO priv (priv_module, priv_name, priv_descrip) VALUES ('Purchase','UnreleasePurchaseOrders','Can Unrelease Purchase Orders.');

